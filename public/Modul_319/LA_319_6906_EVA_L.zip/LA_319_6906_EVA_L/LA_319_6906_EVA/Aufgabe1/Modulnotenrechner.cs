﻿using System;

namespace LA_319_6906_EVA
{
    class Modulnotenrechner
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string modulNummer;         // string: könnte ük-187 (bei IMS-Klassen) sein
            double lbNote;
            double proBeNote;
            double modulNoteUngerundet;
            double modulNoteGerundet;

            // Eingabe
            Console.Write("Modul-Nummer: ");
            modulNummer = Console.ReadLine();
            
            Console.Write("LB-Note: ");
            lbNote = Convert.ToDouble(Console.ReadLine());

            Console.Write("ProBe-Note: ");
            proBeNote = Convert.ToDouble(Console.ReadLine());

            // Verarbeitung
            modulNoteUngerundet = lbNote * 0.8 + proBeNote * 0.2;
            modulNoteGerundet = Math.Round(modulNoteUngerundet * 2, MidpointRounding.AwayFromZero) / 2;

            // Ausgabe
            Console.Write("Du hast im Modul M" + modulNummer +  " die Note " + modulNoteGerundet + " erreicht. ");
            Console.WriteLine("Diese setzt sich folgendermassen zusammen:");
            Console.WriteLine("LB-Note (80 %):\t" + lbNote);
            Console.WriteLine("ProBe (20 %):\t" + proBeNote);
        }
    }
}