﻿using System;

namespace LA_319_6906_EVA
{
    class Modulnotenrechner
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string modulNummer;         // string: könnte ük-187 (bei IMS-Klassen) sein
            double lbNote;
            double proBePunkteAufgabe1;
            double proBePunkteAufgabe2;
            double proBePunktePortfolio;
            double proBePunkteGesamt;
            const double proBePunkteMax = 3;
            double proBeNoteUngerundet;
            double proBeNotegerundet;
            double modulNoteUngerundet;
            double modulNoteGerundet;

            // Eingabe
            Console.Write("Modul-Nummer: ");
            modulNummer = Console.ReadLine();

            Console.Write("LB-Note: ");
            lbNote = Convert.ToDouble(Console.ReadLine());

            Console.Write("ProBe - Punkte Aufgabe 1: ");
            proBePunkteAufgabe1 = Convert.ToDouble(Console.ReadLine());

            Console.Write("ProBe - Punkte Aufgabe 2: ");
            proBePunkteAufgabe2 = Convert.ToDouble(Console.ReadLine());

            Console.Write("ProBe - Punkte Portfolio: ");
            proBePunktePortfolio = Convert.ToDouble(Console.ReadLine());

            // Verarbeitung
            proBePunkteGesamt = proBePunkteAufgabe1 * 0.25 + proBePunkteAufgabe2 * 0.25 + proBePunktePortfolio * 0.5;
            proBeNoteUngerundet = Math.Round(proBePunkteGesamt / proBePunkteMax * 5 + 1, 1);
            modulNoteUngerundet = lbNote * 0.8 + proBeNoteUngerundet * 0.2;
            modulNoteGerundet = Math.Round(modulNoteUngerundet * 2, MidpointRounding.AwayFromZero) / 2;

            // Ausgabe
            Console.Write("Du hast im Modul M" + modulNummer + " die Note " + modulNoteGerundet + " erreicht. ");
            Console.WriteLine("Diese setzt sich folgendermassen zusammen:");
            Console.WriteLine("LB-Note (80 %):\t" + lbNote);
            Console.WriteLine("ProBe (20 %):\t" + proBeNoteUngerundet);
            Console.WriteLine("\tAufgabenkontrolle 1:\t" + proBePunkteAufgabe1);
            Console.WriteLine("\tAufgabenkontrolle 2:\t" + proBePunkteAufgabe2);
            Console.WriteLine("\tPortfolio-Artikel:\t" + proBePunktePortfolio);
        }
    }
}
