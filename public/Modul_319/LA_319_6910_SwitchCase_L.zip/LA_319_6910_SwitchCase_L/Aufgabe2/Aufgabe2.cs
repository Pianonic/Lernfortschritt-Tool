﻿using System;

namespace Aufgabe2
{
    class Aufgabe2
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string wochentag;

            // Eingabe
            Console.Write("Welcher Tag ist heute? ");
            wochentag = Console.ReadLine();

            // Verarbeitung + Ausgabe
            switch (wochentag)
            {
                case "Montag":
                case "Mittwoch":
                    Console.WriteLine("Heute haben Sie an der BBB Unterricht");
                    break;
                case "Dienstag":
                case "Donnerstag":
                case "Freitag":
                    Console.WriteLine("Gehen Sie zur Arbeit / an die Kanti");
                    break;
                case "Samstag":
                case "Sonntag":
                    Console.WriteLine("Schlafen Sie aus!");
                    break;
                default:
                    Console.WriteLine("Dies ist kein Wochentag!");
                    break;
            }
        }
    }
}
