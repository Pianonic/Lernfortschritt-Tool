﻿using System;

namespace Aufgabe3
{
    class Aufgabe3
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            int chancenInProzent = -1;

            // Eingabe
            try
            {
                Console.Write("Wie stehen die Chancen in Prozent? [0-100] ");
                chancenInProzent = Convert.ToInt32(Console.ReadLine());
                if (chancenInProzent < 0 || chancenInProzent > 100)
                {
                    throw new Exception("Zahl ungültig");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Environment.Exit(0);
            }

            // Verarbeitung + Ausgabe
            switch (chancenInProzent)
            {
                case 0:
                    Console.WriteLine("Sie haben keine Chance.");
                    break;
                case int n when (n < 25):
                    Console.WriteLine("Die Chancen stehen schlecht.");
                    break;
                case int n when (n < 50):
                    Console.WriteLine("Es sieht nicht so gut aus.");
                    break;
                case 50:
                    Console.WriteLine("Die Chancen stehen 50:50.");
                    break;
                case int n when (n < 75):
                    Console.WriteLine("Es könnte klappen.");
                    break;
                case int n when (n < 100):
                    Console.WriteLine("Es sieht gut aus.");
                    break;
                case 100:
                    Console.WriteLine("Es kann nichts schiefgehen.");
                    break;
                default:
                    Console.WriteLine("Die Chancen können nicht eingeschätzt werden.");
                    break;
            }
        }
    }
}
