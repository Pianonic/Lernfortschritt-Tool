﻿using System;

namespace Aufgabe4
{
    class Aufgabe4
    {
        static void Main(string[] args)
        {
            for (int i = 0; i < 9; i++)
            {
                switch (i)
                {
                    case 0:
                        Console.Write("Wenn hinter");
                        break;
                    case 1:
                    case 2:
                    case 6:
                    case 7:
                        Console.Write(" Fliegen");
                        break;
                    case 3:
                    case 5:
                        Console.Write(" fliegen");
                        break;
                    case 4:
                        Console.Write(",");
                        break;
                    case 8:
                        Console.Write(" nach.");
                        break;
                }
            }
        }
    }
}
