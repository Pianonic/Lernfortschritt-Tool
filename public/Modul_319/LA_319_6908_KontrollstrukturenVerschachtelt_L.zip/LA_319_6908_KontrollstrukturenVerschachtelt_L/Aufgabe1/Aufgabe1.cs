﻿using System;

namespace Aufgabe1
{
    class Aufgabe1
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            const int stundenProTag = 24;
            const int minutenProStunde = 60;
            const int sekundenProMinute = 60;

            for (int stunden = 0; stunden < stundenProTag; stunden++)
            {
                for (int minuten = 0; minuten < minutenProStunde; minuten++)
                {
                    for (int sekunden = 0; sekunden < sekundenProMinute; sekunden++)
                    {
                        Console.WriteLine(string.Format("{0:00}:{1:00}:{2:00}", stunden, minuten, sekunden));
                        
                        // Alternative 1:
                        //Console.WriteLine(stunden.ToString("00") + ":" + minuten.ToString("00") + ":" + sekunden.ToString("00"));

                        // Alternative 2:
                        //string stundenFormatiert = stunden.ToString().PadLeft(2, '0');
                        //string minutenFormatiert = minuten.ToString().PadLeft(2, '0');
                        //string sekundenFormatiert = sekunden.ToString().PadLeft(2, '0');
                        //Console.WriteLine(stundenFormatiert + ":" + minutenFormatiert + ":" + sekundenFormatiert);
                    }
                }
            }
        }
    }
}
