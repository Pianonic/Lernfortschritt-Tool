﻿using System;

namespace Aufgabe2
{
    class Aufgabe2
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            const int lower = 1;
            const int upper = 100;
            string auswahl;
            Random rnd = new Random();
            int zufallszahl = -1;

            // Eingabe
            Console.WriteLine("Sie bekommen eine Zufallszahl zwischen " + lower + " und " + upper + ".");
            Console.Write("Wünschen Sie sich eine gerade (g) oder eine ungerade (u) Zahl? [g|u] ");
            auswahl = Console.ReadLine();

            // Verarbeitung
            if (auswahl == "g")
            {
                do
                {
                    zufallszahl = rnd.Next(lower, upper + 1);
                } while (zufallszahl % 2 != 0);
            }
            else if (auswahl == "u")
            {
                do
                {
                    zufallszahl = rnd.Next(lower, upper + 1);
                } while (zufallszahl % 2 == 0);
            }
            else
            {
                // Behandlung einer Fehleingabe
                Console.WriteLine("Ungültige Auswahl.");
                Environment.Exit(0);
            }

            // Ausgabe
            Console.WriteLine("Ihre Zufallszahl lautet " + zufallszahl);
        }
    }
}
