﻿using System;

namespace LA_319_6904_MeyerLars
{
    class Program
    {
        static void Main(string[] args)
        {
            // Deklarationen + Initialisierung
            string vornameNachname = "Lars Meyer";                          // a
            DateTime naechsteModulpruefung = new DateTime(2021, 11, 12);    // b
            const string Blutgruppe = "A+";                                 // c
            double erwarteteNote = 5.5;                                     // d
            char klassenbezeichnung = 'a';                                  // e
            bool schuelerausweisErhalten = false;                           // f
            int glueckszahl = new Random().Next(1, 100);                    // g

            // Änderungen
            // Blutgruppe = "AB-"   --> funktioniert nicht                  // h
            erwarteteNote = 6.0;                                            // i
            
            // Ausgaben
            Console.WriteLine(vornameNachname);
            Console.WriteLine(naechsteModulpruefung);
            Console.WriteLine(Blutgruppe);
            Console.WriteLine(erwarteteNote);
            Console.WriteLine(klassenbezeichnung);
            Console.WriteLine(schuelerausweisErhalten);
            Console.WriteLine(glueckszahl);
        }
    }
}
