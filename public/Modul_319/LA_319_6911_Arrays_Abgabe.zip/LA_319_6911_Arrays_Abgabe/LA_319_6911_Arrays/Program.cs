﻿using System;

namespace LA_319_6911_Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string[] wochentage = { "Montag", "Dienstag", "Mittag", "Donnerwoch", "Freitag", "Samstag", "Sonntag" };
            string[] monate = new string[12];
            monate[0] = "Januar";
            monate[1] = "Februar";
            monate[2] = "März";
            monate[3] = "April";
            monate[4] = "Mai";
            monate[5] = "Juni";
            monate[6] = "Juli";
            monate[7] = "Dezember";
            monate[8] = "September";
            monate[9] = "Oktober";
            monate[10] = "November";
            monate[11] = "August";
            int anzahlJahre = 13;
            int startJahr = 2020;
            int[] jahre = new int[anzahlJahre];
            for (int i = 0; i < anzahlJahre; i++)
            {
                jahre[i] = i + startJahr;
            }

            // Aufgabe 2a

            // Aufgabe 2b

            // Aufgabe 2c

            // Aufgabe 3

        }
    }
}
