﻿using System;

namespace LA_319_Arrays
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string[] wochentage = { "Montag", "Dienstag", "Mittag", "Donnerwoch", "Freitag", "Samstag", "Sonntag" };
            string[] monate = new string[12];
            monate[0] = "Januar";
            monate[1] = "Februar";
            monate[2] = "März";
            monate[3] = "April";
            monate[4] = "Mai";
            monate[5] = "Juni";
            monate[6] = "Juli";
            monate[7] = "Dezember";
            monate[8] = "September";
            monate[9] = "Oktober";
            monate[10] = "November";
            monate[11] = "August";
            int anzahlJahre = 13;
            int startJahr = 2020;
            int[] jahre = new int[anzahlJahre];
            for (int i = 0; i < anzahlJahre; i++)
            {
                jahre[i] = i + startJahr;
            }

            // Aufgabe 2a
            wochentage[2] = "Mittwoch";
            wochentage[3] = "Donnerstag";

            // Aufgabe 2b
            Console.WriteLine("Heute ist ein " + wochentage[0] + " im " + monate[11] + " " + jahre[1]);

            // Aufgabe 2c
            string zwischenspeicher = monate[11];
            monate[11] = monate[7];
            monate[7] = zwischenspeicher;

            // Aufgabe 3
            Console.WriteLine(Environment.NewLine + "Wochentage:");
            // Möglichkeit 1, über ein Array zu iterieren.
            for (int i = 0; i < wochentage.Length; i++)
            {
                Console.WriteLine(wochentage[i]);
            }
            Console.WriteLine(Environment.NewLine + "Monate:");
            // Möglichkeit 2, über ein Array zu iterieren.
            // In diesem Fall eleganter, da der Index ausser zur Referenzierung des Elementes nicht gebraucht wird.
            foreach (string monat in monate)
            {
                Console.WriteLine(monat);
            }
        }
    }
}
