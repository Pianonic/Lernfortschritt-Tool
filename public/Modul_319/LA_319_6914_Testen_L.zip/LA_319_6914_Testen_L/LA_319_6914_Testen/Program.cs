﻿using System;

namespace LA_319_6914_Testen
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            int seiteA = -1;
            int seiteB = -1;
            int flaeche;

            // Eingabe
            try
            {
                Console.Write("Geben Sie Bitte die Seitenlänge a ein: ");
                seiteA = Convert.ToInt32(Console.ReadLine());
                Console.Write("Geben Sie Bitte die Seitenlänge b ein: ");
                seiteB = Convert.ToInt32(Console.ReadLine());

                if (seiteA < 1 || seiteB < 1)
                {
                    throw new Exception("Die Seitenlängen müssen mindestens 1 sein.");
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                Environment.Exit(0);
            }

            // Verarbeitung
            flaeche = seiteA * seiteB;

            // Ausgabe
            Console.WriteLine("Die Fläche des Rechtecks ist " + flaeche);
        }
    }
}
