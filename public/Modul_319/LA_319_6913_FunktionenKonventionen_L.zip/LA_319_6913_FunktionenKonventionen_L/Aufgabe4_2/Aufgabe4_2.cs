﻿using System;

namespace Aufgabe4_2
{
    class Aufgabe4_2
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            uint dezimalzahl;
            uint zwischenwert;
            uint rest;
            String hexadezimalzahl = "";
            const int Basis = 16;

            // Eingabe
            dezimalzahl = PositiveGanzzahlSicherAbfragen("Geben Sie eine positive Ganzzahl ein: ");
            zwischenwert = dezimalzahl;

            // Verarbeitung - Divisionsmethode (Restverfahren)
            while (zwischenwert > 15)
            {
                rest = zwischenwert % Basis;
                hexadezimalzahl = Digit2Hex(rest) + hexadezimalzahl;
                zwischenwert = (zwischenwert - rest) / Basis;
            }
            hexadezimalzahl = Digit2Hex(zwischenwert) + hexadezimalzahl;

            // Ausgabe
            Console.WriteLine("Dezimalzahl {0} --> Hexadezimalzahl {1} ", dezimalzahl, hexadezimalzahl);
        }

        // Wandelt eine gegebene Dezimalzahl zwischen 0 und 15 in eine Hexadezimalzahl um
        static string Digit2Hex(uint dezimalzahl)
        {
            string hexZahl = "";
            String[] hexSymbole = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
            try
            {
                hexZahl = hexSymbole[dezimalzahl];
            }
            catch
            {
                Console.WriteLine("Ungültige Konvertierung");
                System.Environment.Exit(0);
            }
            return hexZahl;
        }

        // Fragt eine positive Ganzzahl sicher ab
        static uint PositiveGanzzahlSicherAbfragen(string abfrageText)
        {
            bool eingabeUngueltig;
            uint ganzzahl = 0;
            do
            {
                eingabeUngueltig = true;
                try
                {
                    Console.Write(abfrageText);
                    ganzzahl = Convert.ToUInt32(Console.ReadLine());
                    eingabeUngueltig = false;
                }
                catch
                {
                    Console.WriteLine("Ungültige Eingabe.");
                }
            } while (eingabeUngueltig);
            return ganzzahl;
        }
    }
}
