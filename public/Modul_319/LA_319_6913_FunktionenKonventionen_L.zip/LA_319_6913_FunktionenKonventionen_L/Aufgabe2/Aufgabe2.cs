﻿using System;

namespace LA_319_6913_FunktionenKonventionen
{
    class Aufgabe2
    {
        /*
         * Das Programm gibt eine formatierte Liste für
         * gegebene Artikelnummern / -preise aus.
         */
        static void Main(string[] args)
        {
            // Variablendeklaration
            uint anzahlPositionen = 0;
            uint[] artikelnummernListe;
            uint[] preiseInRappenListe;
            int maxPositionLaenge;
            int maxArtikelnummerLaenge;
            int maxPreisLaenge;

            // Eingabe Anzahl Positionen
            anzahlPositionen = PositiveGanzzahlSicherAbfragen("Geben Sie die Anzahl Positionen ein: ");

            // Listen-initialisierung
            artikelnummernListe = new uint[anzahlPositionen];
            preiseInRappenListe = new uint[anzahlPositionen];

            // Eingabe Artikel + Preise
            for (int i = 0; i < anzahlPositionen; i++)
            {
                artikelnummernListe[i] = PositiveGanzzahlSicherAbfragen("Geben Sie die " + (i + 1) + ". Artikelnummer ein: ");
                preiseInRappenListe[i] = PositiveGanzzahlSicherAbfragen("Geben Sie den " + (i + 1) + ". Preis ein: ");
            }

            // Länge der*des grössten Position*Artikelnummer*Preises ermitteln            
            maxPositionLaenge = anzahlPositionen.ToString().Length;
            maxArtikelnummerLaenge = MaxElementLaengeErmitteln(artikelnummernListe);
            maxPreisLaenge = MaxElementLaengeErmitteln(preiseInRappenListe);

            // Formatierte Ausgabe
            Console.WriteLine(Environment.NewLine + "Preisliste:");
            for (uint i = 0; i < anzahlPositionen; i++)
            {
                string position = FormatiereUInt(i + 1, maxPositionLaenge);
                string artikel = FormatiereUInt(artikelnummernListe[i], maxArtikelnummerLaenge);
                string preis = FormatierePreis(preiseInRappenListe[i], maxPreisLaenge);
                Console.WriteLine(position + "\t" + artikel + "\t" + preis);
            }
        }

        static uint PositiveGanzzahlSicherAbfragen(string abfrageText)
        {
            bool eingabeUngueltig;
            uint ganzzahl = 0;
            do
            {
                eingabeUngueltig = true;
                try
                {
                    Console.Write(abfrageText);
                    ganzzahl = Convert.ToUInt32(Console.ReadLine());
                    eingabeUngueltig = false;
                }
                catch
                {
                    Console.WriteLine("Ungültige Eingabe.");
                }
            } while (eingabeUngueltig);
            return ganzzahl;
        }

        static int MaxElementLaengeErmitteln(uint[] array)
        {
            int maxLaenge = 0;
            int anzahlStellen;
            for (int i = 0; i < array.Length; i++)
            {
                anzahlStellen = array[i].ToString().Length;
                if (anzahlStellen > maxLaenge)
                {
                    maxLaenge = anzahlStellen;
                }
            }
            return maxLaenge;
        }

        static string FormatiereUInt(uint uInt, int laenge)
        {
            return uInt.ToString().PadLeft(laenge);
        }

        static string FormatierePreis(uint preisInRappen, int maxPreisLaenge)
        {
            double preisInFranken = preisInRappen / 100.00;
            return preisInFranken.ToString("0.00").PadLeft(maxPreisLaenge + 1);
        }
    }
}
