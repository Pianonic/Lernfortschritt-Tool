﻿using System;

namespace Aufgabe4_1
{
    class Aufgabe4_1
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            uint dezimalzahl;
            String hexadezimalzahl;

            // Eingabe
            dezimalzahl = KleineDezimalzahlAbfragen("Geben Sie eine Zahl zwischen 0 und 15 ein: ");

            // Verarbeitung
            hexadezimalzahl = Digit2Hex(dezimalzahl);

            // Ausgabe
            Console.WriteLine("Dezimalzahl {0} --> Hexadezimalzahl {1} ", dezimalzahl, hexadezimalzahl);
        }

        // Wandelt eine gegebene Dezimalzahl zwischen 0 und 15 in eine Hexadezimalzahl um
        static string Digit2Hex(uint dezimalzahl)
        {
            string hexZahl = "";
            String[] hexSymbole = { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "A", "B", "C", "D", "E", "F" };
            try
            {
                hexZahl = hexSymbole[dezimalzahl];
            } catch
            {
                Console.WriteLine("Ungültige Konvertierung");
                System.Environment.Exit(0);
            }
            return hexZahl;            
        }

        // Fragt eine Dezimalzahl zwischen 0 und 15 sicher ab
        static uint KleineDezimalzahlAbfragen(string abfrageText)
        {
            bool eingabeUngueltig;
            uint ganzzahl = 0;
            do
            {
                eingabeUngueltig = true;
                try
                {
                    Console.Write(abfrageText);
                    ganzzahl = Convert.ToUInt32(Console.ReadLine());
                    if (ganzzahl > 15)
                    {
                        throw new Exception();
                    }
                    eingabeUngueltig = false;
                }
                catch
                {
                    Console.WriteLine("Ungültige Eingabe.");
                }
            } while (eingabeUngueltig);
            return ganzzahl;
        }
    }
}
