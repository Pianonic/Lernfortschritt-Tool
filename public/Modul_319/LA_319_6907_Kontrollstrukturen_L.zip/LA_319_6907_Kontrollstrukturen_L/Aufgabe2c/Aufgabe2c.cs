﻿using System;

namespace Aufgabe2c
{
    class Aufgabe2c
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string inhaltDesRucksacks = "";
            string gegenstand;

            do
            {
                // Ausgabe
                Console.WriteLine("-----------------------------");
                Console.WriteLine("Ich packe in meinen Rucksack:");

                // Eingabe
                Console.Write(inhaltDesRucksacks);
                gegenstand = Console.ReadLine();

                // Verarbeitung
                inhaltDesRucksacks += gegenstand + Environment.NewLine;
            } while (gegenstand != "");
        }
    }
}
