﻿using System;

namespace Aufgabe2d
{
    class Aufgabe2d
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            int aktuellesAlter;
            const int urAlter = 46;

            // Eingabe
            Console.Write("Wie alt sind Sie? ");
            aktuellesAlter = Convert.ToInt32(Console.ReadLine());

            // Verarbeitung + Ausgabe
            Console.WriteLine("In " + (urAlter - aktuellesAlter) + " Jahren sind Sie " + urAlter + " Jahre alt.");
        }
    }
}
