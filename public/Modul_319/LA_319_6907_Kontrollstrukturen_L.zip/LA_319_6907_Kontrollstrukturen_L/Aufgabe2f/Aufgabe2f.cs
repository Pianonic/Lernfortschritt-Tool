﻿using System;

namespace Aufgabe2f
{
    class Aufgabe2f
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string richtung;

            // Eingabe
            Console.WriteLine("Sie kommen an eine Kreuzung mit einem Wegweiser.");
            Console.WriteLine("Links ist mit 'Erleuchtung' angeschrieben, Rechts mit 'Untergang'.");
            Console.Write("Für welche Richtung entscheiden Sie sich? [links|rechts] ");
            richtung = Console.ReadLine();

            if (richtung == "links")
            {
                Console.WriteLine("Bravo! Gut gemacht, Sie sind an der BBB gelandet.");
            }
            else if (richtung == "rechts")
            {
                Console.WriteLine("Oh je! Sie stehen vor dem McDonald's. Sehen Sie zu, dass Sie hier wegkommen!");
            }
            else
            {
                Console.WriteLine("Sie stossen Ihren Kopf am Wegweiser an.");
            }
        }
    }
}
