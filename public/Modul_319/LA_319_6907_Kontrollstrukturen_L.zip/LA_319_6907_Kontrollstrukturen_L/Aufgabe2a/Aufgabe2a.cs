﻿using System;

namespace Aufgabe2a
{
    class Aufgabe2a
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            uint zahl;

            // Eingabe
            Console.Write("Geben Sie eine positive Zahl ein: ");
            zahl = Convert.ToUInt32(Console.ReadLine());

            // Verarbeitung
            for (int i = 1; i <= 10; i++)
            {
                // Ausgabe
                Console.WriteLine(i * zahl);
            }
        }
    }
}
