﻿using System;

namespace Aufgabe2b
{
    class Aufgabe2b
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            bool esRegnet;

            // Eingabe
            Console.Write("Regnet es? [true/false] ");
            esRegnet = Convert.ToBoolean(Console.ReadLine());

            // Verarbeitung
            if (esRegnet)
            {
                // Ausgabe
                Console.WriteLine("Spannen Sie bitte den Schirm auf!");
            }
        }
    }
}
