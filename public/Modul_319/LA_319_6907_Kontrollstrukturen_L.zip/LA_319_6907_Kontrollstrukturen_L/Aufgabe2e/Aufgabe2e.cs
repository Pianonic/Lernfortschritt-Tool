﻿using System;

namespace Aufgabe2e
{
    class Aufgabe2e
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            int zahl;

            // Eingabe
            Console.Write("Geben Sie eine Zahl zwischen 1 und 10 ein: ");
            zahl = Convert.ToInt32(Console.ReadLine());

            // Verarbeitung
            while (zahl < 1 || zahl > 10)
            {
                Console.Write("Ungültige Eingabe. Bitte erneut um Zahl zwischen 1 und 10: ");
                zahl = Convert.ToInt32(Console.ReadLine());
            }

            // Ausgabe
            Console.WriteLine("Ihre Wahl fällt auf die " + zahl);
        }
    }
}
