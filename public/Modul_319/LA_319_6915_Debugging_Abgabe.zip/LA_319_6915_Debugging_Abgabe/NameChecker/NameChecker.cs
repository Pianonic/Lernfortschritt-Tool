﻿using System;

namespace NameChecker
{
    class NameChecker
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string name;
            char zeichenZuPruefen;
            bool nameGueltig;
            string gueltigeZeichen = " -AaÄäBbCcDdEeFfGgHhIiJjKkLlMmNnOoÖöPpQqRrSsTtUuÜüVvWwXxVyZz";

            do
            {
                // Benutzer-Eingabe abholen
                Console.Write("Welchen Namen möchten Sie überprüfen?: ");
                name = Console.ReadLine();

                // Bis wir das Gegenteil bewiesen haben, gehen wir davon aus, dass der Name gültig ist
                nameGueltig = true;

                try
                {
                    // Name auf minimale Länge prüfen
                    if (name.Length < 1)
                    {
                        throw new InvalidNameException();
                    }

                    // Name auf Anzahl '-' prüfen
                    if (name.Split('-').Length > 2)
                    {
                        throw new InvalidNameException();
                    }

                    // Name auf Anzahl ' ' prüfen
                    if (name.Split(' ').Length > 2)
                    {
                        throw new InvalidNameException();
                    }

                    // Name auf '-' und ' ' am Anfang und Schluss prüfen
                    if (name[0] == '-' || name[0] == ' ' || name[name.Length - 1] == '-' || name[name.Length - 1] == ' ')
                    {
                        throw new InvalidNameException();
                    }

                    // Name auf aufeinanderfolgende '-' und ' ' prüfen
                    if (name.IndexOf("- ") != -1 || name.IndexOf(" -") != -1)
                    {
                        throw new InvalidNameException();
                    }

                    // Alle Zeichen im Namen durchgehen und einzeln prüfen
                    for (int i = 0; i < name.Length - 1; i++)
                    {
                        zeichenZuPruefen = name[i];
                        // wenn das aktuelle Zeichen nicht in der Liste der gültigen Zeichen ist
                        if (gueltigeZeichen.IndexOf(zeichenZuPruefen) < 0)
                        {
                            throw new InvalidNameException();
                        }
                    }
                }
                catch (InvalidNameException)
                {
                    nameGueltig = false;
                }

                // Ausgabe des Resultates
                Console.WriteLine("Der Name ist " + (nameGueltig ? "gültig" : "ungültig"));

                Console.Write("Möchten Sie einen weiteren Namen überprüfen? [y|n] ");
            }
            while (Console.ReadLine() == "y");

        }
    }
}
