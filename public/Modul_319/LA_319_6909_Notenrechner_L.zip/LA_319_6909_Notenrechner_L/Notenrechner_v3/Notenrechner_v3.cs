﻿using System;

namespace LA_319_Notenrechner_v3
{
    class Notenrechner_v3
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            double aktuelleNote = 0;
            double notenschnitt = 0;
            int anzahlNoten = 0;
            bool weitereNoteEingeben = true;
            bool eingabeValidiert;

            while (weitereNoteEingeben)
            {
                // Eingabe ist bisher nicht korrekt erfolgt
                eingabeValidiert = false;

                // Neue Note abfragen und einlesen
                while (!eingabeValidiert)
                {
                    try
                    {
                        Console.Write("Geben Sie Ihre Note ein: ");
                        aktuelleNote = Convert.ToDouble(Console.ReadLine());
                        if (aktuelleNote < 1 || aktuelleNote > 6 || aktuelleNote % 0.5 != 0)
                        {
                            throw new Exception();
                        }
                        eingabeValidiert = true;
                    }
                    catch
                    {
                        Console.WriteLine("Fehlerhafte Eingabe.");
                        continue;
                    }
                }

                // Schnitt berechnen und ausgeben
                notenschnitt = (notenschnitt * anzahlNoten + aktuelleNote) / ++anzahlNoten;
                Console.WriteLine("Ihr neuer Notenschnitt ist " + notenschnitt);

                // Abfragen und einlesen, ob weitere Noten eingegeben werden sollen
                Console.Write("--- Möchten Sie weitere Noten eingeben? [y|n] ");
                if (Console.ReadLine() == "n")
                {
                    weitereNoteEingeben = false;
                }
            }
        }
    }
}
