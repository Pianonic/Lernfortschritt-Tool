﻿using System;

namespace LA_319_69xx_Notenrechner
{
    class Notenrechner_v1
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            double aktuelleNote = 0;
            double notenschnitt = 0;
            int anzahlNoten = 0;
            bool weitereNoteEingeben = true;

            while(weitereNoteEingeben)
            {
                // Neue Note abfragen und einlesen
                try
                {
                    Console.Write("Geben Sie Ihre Note ein: ");
                    aktuelleNote = Convert.ToDouble(Console.ReadLine());
                }
                catch
                {
                    Console.WriteLine("Fehlerhafte Eingabe.");
                    return;
                }

                // Schnitt berechnen und ausgeben
                notenschnitt = (notenschnitt * anzahlNoten + aktuelleNote) / ++anzahlNoten;
                Console.WriteLine("Ihr neuer Notenschnitt ist " + notenschnitt);

                // Abfragen und einlesen, ob weitere Noten eingegeben werden sollen
                Console.Write("--- Möchten Sie weitere Noten eingeben? [y|n] ");
                if(Console.ReadLine()=="n")
                {
                    weitereNoteEingeben = false;
                }
            }
        }
    }
}
