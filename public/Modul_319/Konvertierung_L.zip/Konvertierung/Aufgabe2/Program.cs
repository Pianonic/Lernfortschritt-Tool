﻿using System;

namespace Aufgabe2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b = 9;
            double c = 84.3;
            long l = 999999999999;
            string t = "5";
            char z = ' ';

            // Ergänzen Sie den Code mit den korrekten Konvertierungen
            a = c; //a = (int) c;
            b = t; //b = Convert.ToInt32(t);
            t = a; //t = Convert.ToString(a);
            z = b; //z = Convert.ToChar(b);
            a = l; //a = (int) l;






        }
    }
}
