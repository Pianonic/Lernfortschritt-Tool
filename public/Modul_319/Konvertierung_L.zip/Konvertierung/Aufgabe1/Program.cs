﻿using System;

namespace Aufgabe1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            double b = a; // implizite Konvertierung
            
            int c = 5;
            int d = 17; 
            double f = 7.65;
            c = (int) f; // explizite Konvertierung (Casting)
            double g = d; // implizite Konvertierung
            string e = "24";
            int h = Convert.ToInt32(e); // Konvertierung mit Hilfsklasse
            g = double.Parse(e); // Konvertierung mit Hilfsklasse
            double i = 8.543;
            float j = (float) i; // explizite Konvertierung (Casting)
        }
    }
}
