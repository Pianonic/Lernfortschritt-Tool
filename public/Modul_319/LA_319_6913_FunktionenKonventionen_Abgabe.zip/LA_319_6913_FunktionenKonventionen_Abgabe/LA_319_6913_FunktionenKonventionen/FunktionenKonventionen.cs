﻿using System;

namespace LA_319_6913_FunktionenKonventionen
{
    class FunktionenKonventionen
    {
        /*
         * Das Programm gibt eine formatierte Liste für
         * gegebene Artikelnummern / -preise aus.
         */
        static void Main(string[] args)
        {
            // Variablendeklaration
            uint anzahlPositionen = 0;
            uint[] artikelnummernListe;
            uint[] preiseInRappenListe;
            bool eingabeUngueltig;
            int maxPositionLaenge;
            int maxArtikelnummerLaenge = 0;
            int maxPreisLaenge = 0;

            // Eingabe Anzahl Positionen
            do
            {
                eingabeUngueltig = true;
                try
                {
                    Console.Write("Geben Sie die Anzahl Positionen ein: ");
                    anzahlPositionen = Convert.ToUInt32(Console.ReadLine());
                    eingabeUngueltig = false;
                }
                catch
                {
                    Console.WriteLine("Ungültige Eingabe.");
                }
            } while (eingabeUngueltig);

            // Listen-initialisierung
            artikelnummernListe = new uint[anzahlPositionen];
            preiseInRappenListe = new uint[anzahlPositionen];

            // Eingabe Artikel + Preise
            for (int i = 0; i < anzahlPositionen; i++)
            {
                // Artikelnummern einlesen
                eingabeUngueltig = true;
                do
                {
                    try
                    {
                        Console.Write("Geben Sie die " + (i + 1) + ". Artikelnummer ein: ");
                        artikelnummernListe[i] = Convert.ToUInt32(Console.ReadLine());
                        eingabeUngueltig = false;
                    }
                    catch
                    {
                        Console.WriteLine("Ungültige Eingabe.");
                    }
                } while (eingabeUngueltig);

                // Preise einlesen
                eingabeUngueltig = true;
                do
                {
                    try
                    {
                        Console.Write("Geben Sie den " + (i + 1) + ". Preis ein: ");
                        preiseInRappenListe[i] = Convert.ToUInt32(Console.ReadLine());
                        eingabeUngueltig = false;
                    }
                    catch
                    {
                        Console.WriteLine("Ungültige Eingabe.");
                    }
                } while (eingabeUngueltig);
            }

            // Länge der*des grössten Position*Artikelnummer*Preises ermitteln            
            maxPositionLaenge = anzahlPositionen.ToString().Length;
            int anzahlArtikelnummerStellen;
            int anzahlPreisStellen;
            for (int i = 0; i < anzahlPositionen; i++)
            {
                anzahlArtikelnummerStellen = artikelnummernListe[i].ToString().Length;
                if (anzahlArtikelnummerStellen > maxArtikelnummerLaenge)
                {
                    maxArtikelnummerLaenge = anzahlArtikelnummerStellen;
                }

                anzahlPreisStellen = preiseInRappenListe[i].ToString().Length;
                if (anzahlPreisStellen > maxPreisLaenge)
                {
                    maxPreisLaenge = anzahlPreisStellen;
                }
            }

            // Formatierte Ausgabe
            Console.WriteLine(Environment.NewLine + "Preisliste:");
            for (uint i = 0; i < anzahlPositionen; i++)
            {
                string position = FormatiereUInt(i + 1, maxPositionLaenge);
                string artikel = FormatiereUInt(artikelnummernListe[i], maxArtikelnummerLaenge);
                string preis = FormatierePreis(preiseInRappenListe[i], maxPreisLaenge);
                Console.WriteLine(position + "\t" + artikel + "\t" + preis);
            }
        }

        // Aufgabe 2b
        static uint PositiveGanzzahlSicherAbfragen(string abfrageText)
        {
            uint ganzzahl = 0;
            // Hier gehört der ausgelagerte Code hin
            return ganzzahl;
        }

        // Aufgabe 2c
        static int MaxElementLaengeErmitteln(uint[] array)
        {
            int maxLaenge = 0;
            // Hier gehört der ausgelagerte Code hin
            return maxLaenge;
        }

        static string FormatiereUInt(uint uInt, int laenge)
        {
            return uInt.ToString().PadLeft(laenge);
        }

        static string FormatierePreis(uint preisInRappen, int maxPreisLaenge)
        {
            double preisInFranken = preisInRappen / 100.00;
            return preisInFranken.ToString("0.00").PadLeft(maxPreisLaenge + 1);
        }
    }
}
