﻿using System;

namespace Aufgabe1
{
    class Program
    {
        static void Main(string[] args)
        {
            int a = 5;
            double b = a; // implizite Konvertierung
            
            int c = 5;
            int d = 17; 
            double f = 7.65;
            c = (int) f;
            double g = d;
            string e = "24";
            int h = Convert.ToInt32(e);
            g = double.Parse(e);
            double i = 8.543;
            float j = (float) i;
        }
    }
}
