﻿using System;

namespace Aufgabe2
{
    class Program
    {
        static void Main(string[] args)
        {
            int a;
            int b = 9;
            double c = 84.3;
            long l = 999999999999;
            string t = "5";
            char z = ' ';

            // Ergänzen Sie den Code mit den korrekten Konvertierungen
            a = c;
            b = t;
            t = a;
            z = b;
            a = l;






        }
    }
}
