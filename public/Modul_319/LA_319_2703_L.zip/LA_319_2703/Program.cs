﻿namespace LA_319_2703
{
    internal class Program
    {
        static void Main(string[] args)
        {
            WriteHelloWorld();
            WriteSomething("Hallo Welt");

            int zahl = Wuerfel();
            Console.WriteLine(zahl);

            zahl = Fibonacci(7);
            Console.WriteLine(zahl);

            double lbNote = 5.3;
            double obaNote = 4.8;
            double notenSchnitt = ModulNote(lbNote, obaNote);
            Console.WriteLine(notenSchnitt);
        }

        //Aufgabe 2
        static void WriteHelloWorld()
        {
            Console.WriteLine("Hello World");
        }

        //Aufgabe 3
        static void WriteSomething(string text)
        {
            Console.WriteLine(text);
        }

        //Aufgabe 4
        static int Wuerfel()
        {
            Random rnd = new Random();
            return rnd.Next(1, 7);
        }

        //Aufgabe 5
        static int Fibonacci(int number)
        {
            int a = 0;
            int b = 1;
            int c;
            
            for (int i = 1; i < number; i++)
            {
                c = b;
                b = b + a;
                a = c;
            }
            return b;
        }

        //Aufgabe 6
        static double ModulNote(double lbNote, double obaNote)
        {
            double result = 0.8 * lbNote + 0.2 * obaNote;
            return result;
        }
    }
}