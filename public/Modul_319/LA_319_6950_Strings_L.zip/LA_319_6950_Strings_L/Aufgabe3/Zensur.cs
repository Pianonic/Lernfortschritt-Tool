﻿using System;

namespace Aufgabe3
{
    class Zensur
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string klartext;
            string zensurierterText;
            string triggerWort;
            const string ZensurWort = "|ZENSUR|";

            // Eingabe
            Console.WriteLine("Klartext:");
            klartext = Console.ReadLine();
            Console.Write("Triggerwort: ");
            triggerWort = Console.ReadLine();

            // Verarbeitung - Zensur
            if(triggerWort.Length > 0)
            {
                zensurierterText = klartext.Replace(triggerWort, ZensurWort);
            } else
            {
                zensurierterText = klartext;
            }
            
            // Ausgabe
            Console.WriteLine("------------------");
            Console.WriteLine("Zensurierter Text:");
            Console.WriteLine(zensurierterText);
        }
    }
}
