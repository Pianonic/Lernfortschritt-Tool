﻿using System;

namespace LA_319_6950_Strings
{
    class Geheimsprache
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string klartext;
            string geheimtext = "";

            // Eingabe
            Console.WriteLine("Klartext:");
            klartext = Console.ReadLine();

            // Verarbeitung
            for(int i = 0; i < klartext.Length; i++)
            {
                switch(klartext[i])
                {
                    case 'A':
                    case 'E':
                    case 'I':
                    case 'O':
                    case 'U':
                        geheimtext += 'Ü';
                        break;
                    case 'Ü':
                        geheimtext += 'Ö';
                        break;
                    case 'a':
                    case 'e':
                    case 'i':
                    case 'o':
                    case 'u':
                        geheimtext += 'ü';
                        break;
                    case 'ü':
                        geheimtext += 'ö';
                        break;
                    default:
                        geheimtext += klartext[i];
                        break;
                }
            }

            // Ausgabe
            Console.WriteLine("Geheimtext:");
            Console.WriteLine(geheimtext);
        }
    }
}
