﻿using System;

namespace Aufgabe4
{
    class ZeitIstGeld
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string klartext;
            string[] einzelneWoerter;
            string gekuerzterText = "";
            int laenge = 0;

            // Eingabe
            Console.WriteLine("Klartext:");
            klartext = Console.ReadLine();
            try
            {
                Console.Write("Maximale Wortlänge: ");
                laenge = Convert.ToInt32(Console.ReadLine());
            } catch
            {
                Console.WriteLine("Fehlerhafte Eingabe.");
                System.Environment.Exit(0);
            }
            
            // Verarbeitung
            einzelneWoerter = klartext.Split(' ');
            foreach(string einzelwort in einzelneWoerter)
            {
                if(einzelwort.Length > laenge)
                {
                    gekuerzterText += einzelwort.Substring(0, laenge) + " ";
                } else
                {
                    gekuerzterText += einzelwort + " ";
                }
                
            }

            // Ausgabe
            Console.WriteLine("---------------");
            Console.WriteLine("Gekürzter Text:");
            Console.WriteLine(gekuerzterText);
        }
    }
}
