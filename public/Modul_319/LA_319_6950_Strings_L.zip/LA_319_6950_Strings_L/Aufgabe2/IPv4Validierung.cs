﻿using System;

namespace Aufgabe2
{
    class IPv4Validierung
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            string ipv4Adresse;
            string[] einzelteile;
            int einzelneZahl;
            bool gueltig = true;

            // Eingabe
            Console.Write("Geben Sie eine IPv4 Adresse ein: ");
            ipv4Adresse = Console.ReadLine();

            // Verarbeitung - Prüfen auf 4 Blöcke mit Punkt getrennt
            einzelteile = ipv4Adresse.Split('.');
            if (einzelteile.Length != 4)
            {
                gueltig = false;
            }

            // Verarbeitung - Prüfen auf Zahlen zwischen 0 und 255
            foreach (string einzelteil in einzelteile)
            {
                try
                {
                    einzelneZahl = Convert.ToInt32(einzelteil);
                    if(einzelneZahl < 0 || einzelneZahl > 255)
                    {
                        throw new Exception();
                    }
                }
                catch
                {
                    gueltig = false;
                }

            }

            // Ausgabe
            Console.WriteLine("Die Adresse ist " + (gueltig ? "gültig" : "ungültig"));
        }
    }
}
