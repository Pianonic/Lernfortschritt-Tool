﻿using System;

namespace LA_319_69xx_QVRechner
{
    class Program
    {
        static void Main(string[] args)
        {
            // Variablendeklaration
            const int maxAnzahlModule = 24;
            int[] module = new int[maxAnzahlModule];
            double[] modulnoten = new double[maxAnzahlModule];
            int aktuellesModul = 0;
            double aktuelleNote = 0;
            int anzahlNoten = 0;
            double notensumme = 0;
            bool weitereNoteEingeben = true;
            bool eingabeValidiert;

            while (weitereNoteEingeben && anzahlNoten < maxAnzahlModule)
            {
                // Eingabe ist bisher nicht korrekt erfolgt
                eingabeValidiert = false;

                // Neue Modulnote abfragen und einlesen
                while (!eingabeValidiert)
                {
                    try
                    {
                        Console.Write("Geben Sie die Modulnummer ein: ");
                        aktuellesModul = Convert.ToInt32(Console.ReadLine());

                        Console.Write("Geben Sie Ihre Note für M" + aktuellesModul + " ein: ");
                        aktuelleNote = Convert.ToDouble(Console.ReadLine());
                        if (aktuelleNote < 1 || aktuelleNote > 6 || aktuelleNote % 0.5 != 0)
                        {
                            throw new Exception();
                        }
                        eingabeValidiert = true;
                    }
                    catch
                    {
                        Console.WriteLine("Fehlerhafte Eingabe.");
                        continue;
                    }
                }

                // Werte in den Arrays platzieren
                module[anzahlNoten] = aktuellesModul;
                modulnoten[anzahlNoten] = aktuelleNote;
                anzahlNoten++;

                // Abfragen und einlesen, ob weitere Noten eingegeben werden sollen.
                Console.WriteLine("-------------------------------------------");
                if (weitereNoteEingeben && anzahlNoten < maxAnzahlModule)
                {
                    Console.Write("Möchten Sie weitere Noten eingeben? [y|n] ");
                    if (Console.ReadLine() == "n")
                    {
                        weitereNoteEingeben = false;
                    }
                }
            }

            // Ausgabe der bisherigen Module und Noten
            Console.WriteLine("-------------------------------------------");
            for (int i = 0; i < anzahlNoten; i++)
            {
                Console.WriteLine("Modul " + module[i] + ":\t" + modulnoten[i]);
                notensumme += modulnoten[i];
            }

            // Berechnung und Ausgabe des Notenschnitts
            Console.WriteLine("------------------------------------");
            Console.WriteLine("Ihr Notenschnitt ist " + notensumme / anzahlNoten);
            Console.WriteLine("------------------------------------");
        }
    }
}
